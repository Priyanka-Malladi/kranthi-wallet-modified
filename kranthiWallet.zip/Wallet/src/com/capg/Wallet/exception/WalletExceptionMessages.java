package com.capg.Wallet.exception;

public class WalletExceptionMessages {

	public static final String ERROR1="Invalid firstname";
	public static final String ERROR2="Invalid lastname";
	public static final String ERROR3="Invalid email";
	public static final String ERROR4="Invalid phonenumber";
	public static final String ERROR5="deposit not possible";
	public static final String ERROR6="insufficient balance";
	public static final String ERROR7="transaction failed..Money Refunded!";
	
}
