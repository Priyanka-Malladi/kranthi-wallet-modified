package com.capg.Wallet.exception;

public class WalletException extends Exception{

	public WalletException() {
		System.out.println("wallet exception raised!!");
		// TODO Auto-generated constructor stub
	}
	 public WalletException(String args) {
		 
		super(args);
	}

}